using UnityEngine;

namespace Delaunay
{
	
	public interface ICoord
	{
		Vector2 Coord {
			get;
		}
	}
}